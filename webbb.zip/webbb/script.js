// ✅ استبدل الرابط برابطك الحقيقي من موقع crudcrud.com
const API_URL = 'https://crudcrud.com/api/230006c4456a4450bae336727f88aa1b/superAppointments';

const form = document.getElementById('appointmentForm');
const tbody = document.querySelector('#appointmentsTable tbody');

window.onload = loadAppointments;

async function loadAppointments() {
  try {
    const res = await fetch(API_URL);
    const data = await res.json();
    renderAppointments(data);
  } catch (error) {
    alert("❌ Failed to load data.");
  }
}

function renderAppointments(list) {
  tbody.innerHTML = '';
  list.forEach(item => {
    const row = document.createElement('tr');
    row.innerHTML = `
      <td>${item.customer}</td>
      <td>${item.product}</td>
      <td>${item.quantity}</td>
      <td>${item.date}</td>
      <td>
        <button class="edit" onclick='editForm(${JSON.stringify(item)})'>Edit</button>
        <button class="delete" onclick='deleteAppointment("${item._id}")'>Delete</button>
      </td>
    `;
    tbody.appendChild(row);
  });
}

function editForm(item) {
  document.getElementById('appointmentId').value = item._id;
  form.customer.value = item.customer;
  form.product.value = item.product;
  form.quantity.value = item.quantity;
  form.date.value = item.date;
}

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  const id = document.getElementById('appointmentId').value;
  const appointment = {
    customer: form.customer.value,
    product: form.product.value,
    quantity: form.quantity.value,
    date: form.date.value
  };

  try {
    if (id) {
      await fetch(`${API_URL}/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(appointment)
      });
    } else {
      await fetch(API_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(appointment)
      });
    }
    form.reset();
    document.getElementById('appointmentId').value = '';
    loadAppointments();
  } catch (error) {
    alert("❌ Failed to save.");
  }
});

async function deleteAppointment(id) {
  if (!confirm("🗑️ Delete this appointment?")) return;
  try {
    await fetch(`${API_URL}/${id}`, { method: 'DELETE' });
    loadAppointments();
  } catch (error) {
    alert("❌ Failed to delete.");
  }
}
